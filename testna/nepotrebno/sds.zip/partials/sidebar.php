<div class="sidebar">
    <div class="sidebar-inner">
        <h3 class="sidebar-title">Kategorije</h3>
        <div class="category-list">
            <a href="?" class="category-item <?= empty($izbrana_kategorija) ? 'active' : '' ?>">Vse kategorije</a>
            <?php foreach ($kategorije as $kat): ?>
            <a href="?kategorija=<?= $kat['id_ka'] ?>" 
               class="category-item <?= ($kat['id_ka'] == $izbrana_kategorija) ? 'active' : '' ?>">
               <?= htmlspecialchars($kat['ime']) ?>
            </a>
            <?php endforeach; ?>
        </div>
        
        <div class="price-filter">
            <h3 class="filter-title">Filtriraj po ceni</h3>
            <input type="range" class="price-range" min="0" max="2000" value="2000">
            <div class="price-labels">
                <span>0€</span>
                <span>2000€</span>
            </div>
        </div>
    </div>
</div>