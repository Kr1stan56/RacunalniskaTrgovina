<header class="main-header">
    <div class="header-container">
        <div class="logo">
            <img src="images/logo.png" alt="Logotip trgovine" class="logo-img">
        </div>
        
        <nav class="main-nav">
            <ul class="nav-list">   
                <li class="nav-item"><a href="index.php">Domov</a></li>
                <li class="nav-item"><a href="izdelki.php">Izdelki</a></li>
                <li class="nav-item"><a href="o-nas.php">O nas</a></li>
                <li class="nav-item"><a href="kontakt.php">Kontakt</a></li>
            </ul>
        </nav>
        
        <div class="user-actions">
            <a href="login.php" class="login-btn">Prijava / Registracija</a>
            <a href="#" class="cart-icon"><i class="fas fa-shopping-cart"></i> <span class="cart-count">0</span></a>
        </div>
    </div>
</header>