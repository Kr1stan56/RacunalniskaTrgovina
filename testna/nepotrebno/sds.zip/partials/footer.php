<footer class="main-footer">
    <div class="footer-container">
        <div class="footer-section">
            <h3>O nas</h3>
            <p>Računalniška trgovina z več kot 10 letnimi izkušnjami na področju prodaje računalniške opreme.</p>
        </div>
        
        <div class="footer-section">
            <h3>Kontakt</h3>
            <ul>
                <li><i class="fas fa-map-marker-alt"></i> Naslov 123, 1000 Ljubljana</li>
                <li><i class="fas fa-phone"></i> +386 40 123 456</li>
                <li><i class="fas fa-envelope"></i> info@trgovina.si</li>
            </ul>
        </div>
        
        <div class="footer-section">
            <h3>Hitre povezave</h3>
            <ul>
                <li><a href="index.php">Domov</a></li>
                <li><a href="izdelki.php">Izdelki</a></li>
                <li><a href="#">Košarica</a></li>
                <li><a href="#">Pogoji uporabe</a></li>
                <li><a href="#">Pravilnik o zasebnosti</a></li>
            </ul>
        </div>
        
        <div class="footer-section">
            <h3>Novice</h3>
            <p>Naročite se na naše novice za najnovejše ponudbe.</p>
            <form class="newsletter-form">
                <input type="email" placeholder="Vaš e-mail">
                <button type="submit" class="btn">Naroči se</button>
            </form>
        </div>
    </div>
    
    <div class="footer-bottom">
        <p>&copy; <?= date('Y') ?> Računalniška Trgovina. Vse pravice pridržane.</p>
        <div class="social-icons">
            <a href="#"><i class="fab fa-facebook"></i></a>
            <a href="#"><i class="fab fa-twitter"></i></a>
            <a href="#"><i class="fab fa-instagram"></i></a>
        </div>
    </div>
</footer>