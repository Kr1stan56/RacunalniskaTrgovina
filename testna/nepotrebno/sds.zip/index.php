<?php
require_once 'baza.php';
?>

<!DOCTYPE html>
<html lang="sl">
<head>
    <?php include 'partials/header.php'; ?>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Domov | Računalniška Trgovina</title>
	<link rel="stylesheet" href="css/style.css">


    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
</head>
<body class="home-page">
    
    <main class="main-content full-width">
        <div class="hero-section">
            <h1>Dobrodošli v Računalniški Trgovini</h1>
            <p>Vaša prva postaja za vso računalniško opremo in komponente</p>
            <div class="cta-buttons">
                <a href="izdelki.php" class="btn-primary">Oglejte si izdelke</a>
                <a href="kontakt.php" class="btn-secondary">Kontaktirajte nas</a>
            </div>
        </div>

        <div class="usp-section">
            <div class="usp-box">
                <i class="fas fa-rocket"></i>
                <h3>Hitra Dostava</h3>
                <p>Dostava v 24h po vsej Sloveniji</p>
            </div>
            <div class="usp-box">
                <i class="fas fa-shield-alt"></i>
                <h3>2+1 Garancija</h3>
                <p>Podaljšana garancija za vse izdelke</p>
            </div>
            <div class="usp-box">
                <i class="fas fa-comments"></i>
                <h3>Strokovno Svetovanje</h3>
                <p>Brezplačno svetovanje naših strokovnjakov</p>
            </div>
        </div>
    </main>

    <?php include 'partials/footer.php'; ?>
</body>
</html>