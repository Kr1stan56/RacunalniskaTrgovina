<?php
require_once 'baza.php';

$izbrana_kategorija = isset($_GET['kategorija']) ? intval($_GET['kategorija']) : null;

if ($izbrana_kategorija) {
    $stmt = $conn->prepare("SELECT * FROM izdelek WHERE id_ka = ?");
    $stmt->bind_param("i", $izbrana_kategorija);
    $stmt->execute();
    $result = $stmt->get_result();
    $izdelki = $result->fetch_all(MYSQLI_ASSOC);
} else {
    $stmt = $conn->prepare("
        SELECT * FROM (
            SELECT *, ROW_NUMBER() OVER (PARTITION BY id_ka ORDER BY id_i) AS row_num 
            FROM izdelek
        ) AS temp WHERE row_num <= 5
    ");
    $stmt->execute();
    $result = $stmt->get_result();
    $izdelki = $result->fetch_all(MYSQLI_ASSOC);
}

// Pridobivanje kategorij iz baze
$stmt = $conn->prepare("SELECT * FROM kategorije");
$stmt->execute();
$result = $stmt->get_result();
$kategorije = $result->fetch_all(MYSQLI_ASSOC);
?>


<!DOCTYPE html>
<html lang="sl">
<head>
    <?php include 'partials/header.php'; ?>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Izdelki | Računalniška Trgovina</title>
    <link rel="stylesheet" href="css/style.css">

</head>
<body>
    <?php include 'partials/sidebar.php'; ?>
    
    <main class="main-content">
        <h1 class="page-title">Naši izdelki</h1>
        <div class="product-grid">
            <?php foreach ($izdelki as $izdelek): ?>
                <div class="product-card">
                    <img src="<?= htmlspecialchars($izdelek['slika']) ?>" 
                         class="product-image"
                         alt="<?= htmlspecialchars($izdelek['ime']) ?>">
                    
                    <div class="card-body">
                        <h3 class="product-title"><?= htmlspecialchars($izdelek['ime']) ?></h3>
                        <p class="product-description"><?= htmlspecialchars($izdelek['opis']) ?></p>
                    </div>
                    
                    <div class="card-footer">
                        <div class="price-section">
                            <span class="price"><?= number_format($izdelek['cena'], 2) ?> €</span>
                            <button class="cart-button">
                                <i class="fas fa-cart-plus"></i>
                            </button>
                        </div>
                        <small class="stock">Na zalogi: <?= $izdelek['zaloga'] ?></small>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    </main>

    <?php include 'partials/footer.php'; ?>
</body>
</html>