<?php
$target_dir = "uploads/";

?>