<footer class="footer">
    <div class="noga-vsebina">

        <div class="noga-blok">
            <h3>O nas</h3>
            <p>Računalniška trgovina z več kot 10 letnimi izkušnjami na področju prodaje računalniške opreme.</p>
        </div>
        
        <div class="noga-blok">
            <h3>Kontakt</h3>
            <ul class="kontaktni-podatki">
                <li><i class="fas fa-map-marker-alt"></i> Naslov 123, 1000 Ljubljana</li>
                <li><i class="fas fa-phone"></i> +386 40 123 456</li>
                <li><i class="fas fa-envelope"></i> info@trgovina.si</li>
            </ul>
        </div>
        
        <div class="noga-blok">
            <h3>Viri</h3>
            <ul class="hitre-povezave">
                <li><a href="#">Vodena vaja</a></li>
                <li><a href="https://www.w3schools.com/php/php_file_upload.asp">W3schools files</a></li>
                <li><a href="https://www.w3schools.com/php/func_mysqli_prepare.asp">w3schools prepare</a></li>
                <li><a href="https://www.w3schools.com/php/func_misc_uniqid.asp">w3school uniqid</a></li>
                <li><a href="https://www.w3schools.com/php/func_filesystem_pathinfo.asp">W3schools PATHINFO_EXTENSION</a></li>
            </ul>
        </div>
        <div class="noga-blok">
            <h3>Viri</h3>
            <ul class="hitre-povezave">
                <li><a href="#">Vodena vaja</a></li>
                <li><a href="https://www.w3schools.com/php/func_mysqli_fetch_assoc.asp">W3schools assoc</a></li>
                <li><a href="https://www.w3schools.com/cybersecurity/cybersecurity_web_applications_attacks.php">w3schools SECURITY</a></li>
                <li><a href="https://chatgpt.com">error handling</a></li>
                <li><a href="https://www.w3schools.com/php/php_superglobals_get.asp">w3schools get</a></li>
            </ul>
        </div>
        
        
    </div>
    
    <div class="noga-spodaj">
        <p>&copy; <?= date('Y') ?> Računalniška Trgovina. Vse pravice pridržane.</p>
        
    </div>
</footer>
